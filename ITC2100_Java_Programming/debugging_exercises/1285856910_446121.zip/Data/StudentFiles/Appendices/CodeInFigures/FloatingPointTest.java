import java.util.Scanner;
public class FloatingPointTest
{
   public static void main(String[] args)
   {
      double oneTenth = 0.1;
      double threeTenths = 0.3;
      System.out.println(oneTenth + oneTenth + oneTenth);
      System.out.println(oneTenth + oneTenth + oneTenth ==
        threeTenths);
   }
}
