public class Cow extends Animal
{
   @Override
   public void speak()
   {
      System.out.println("Moo!");
   }
}
