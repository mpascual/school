public class HelloErrors
{
   public static void main(String[] args)
   {
      System.out.println("Hello");
      System.out.println("This is a test");
   }
}