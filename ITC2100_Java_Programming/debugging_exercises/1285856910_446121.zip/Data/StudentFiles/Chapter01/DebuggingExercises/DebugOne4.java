import javax.swing.JOptionPane;
public class DebugOne4
{
  public static main(String[] args)
  {
     JOptionPane.showMessageDialog(null, First GUI program)!
  }
}
