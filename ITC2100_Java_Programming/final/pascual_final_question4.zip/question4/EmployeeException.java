public class EmployeeException extends Exception {
  public EmployeeException(String choice) {
    super(choice);
  }
}
