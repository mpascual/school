public class Horse {
  private String name;
  private String color;
  private int birthYear;

  public String getName() {
    return name;
  }

  public String getColor() {
    return color;
  }

  public int getBirthYear() {
    return birthYear;
  }

  public void setName(String horseName) {
    name = horseName;
  }

  public void setColor(String horseColor) {
    color = horseColor;
  }

  public void setBirthYear(int horseYear) {
    birthYear = horseYear;
  }
}
