public class ApartmentException extends Exception {
  public ApartmentException(String choice) {
    super(choice);
  }
}
