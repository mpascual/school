public class Card {
  char suit;
  int num;

  // set methods
  public void setSuit(char suitChar) {
    suit = suitChar;
  }

  public void setNum(int numValue) {
    num = numValue;
  }

  // get methods
  public char getSuit() {
    return suit;
  }

  public int getNum() {
    return num;
  }
}
